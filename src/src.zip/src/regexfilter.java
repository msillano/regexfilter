/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  http://gnu.org/licenses/gpl.html
 */

/**
 * @file regexfilter.java
 * Filter input text using regex/replacement pairs.
 *
 *  General purpose filter, replaces regular expressions (regex) in the input stream.
 *  This tool can helps,e.g. to create a 'c-like' syntax from shell script and other
 *  languages, suitable to be processed by Doxygen, to change dialects of G-code, etc.
 *  It works like egrep and sed, or like Perl regex, but it is simpler and  it can be
 *  used on Unix/Linux  and  Windows O.S.
 *
 * @pre
 *
 *      - input: standard input (allows piping) or file.
 *      - output: standard output or file.
 *      - regex: all pairs regex/replacement are in a file.
 *      - works line by line or on whole input.
 *      - macros: expansions in replacement strings.
 *
 * @author (c)2006-20015 M. Sillano (marco.sillano@gmail.com)
 * @version 4.03 (15/12/10): Java 1.8, indexes in 1..999, more macros: $E,$D,$C,$T
 * @version 4.02 10/11/25: start version
 */

import java.io.*;
import java.nio.charset.Charset;
import java.util.Calendar;
import java.util.Date;
import java.text.SimpleDateFormat;

import ms.utils.aarray.baseapp.AABaseAppl;
import ms.utils.aarray.baseapp.filter.ZeroFilter;

/**
 * This application implements a text filter for multiple
 * replacements using regular expressions (regex).<br>
 *
 * Extends ZeroFilter defining private data
 * structures: version, help, Option, Parameter and default datFile name.<BR>
 * Input/Output from/to files or standard in/out. <BR>
 * If the Option "b" is true, the input is processed as a whole (block mode),
 * else it is processed line by line.<BR>
 * If the Option "x" is true, the datFile file is in XML format, else datFile is
 * in plain text format. This application can read options from command line or
 * from a config file: the config file can also include the regex/replacement
 * pairs. <BR>
 *
 *
 * It filters the input stream, via java.String.replaceAll(), using
 * regex/replacement pairs.@n All regex/replacement pairs are stored in an ASCII
 * file, and they are all processed in sequence for every input line or for the
 * whole input (block mode).
 *
 * <h4> use </h4>
 *
 * <PRE>
 Usage:     regexfilter -h|-?|--help|--version",
            regexfilter [-bx] [-i=FILE] [-u=FILE] [datFile]",
            regexfilter [--CTextconfigload=FILE]|[--CXmlconfigload=FILE] "

            Filters the inputFile, using regex/replacement pairs in datFile.

            options:  -h|-?|--help    display this help and exit.
                      --version       print version and exit.
                      -b              block mode. Default = line mode.
                      -x              datFile in XML mode. Default = plain text.
            -i=FILE, --input=FILE     the text input file.
                                      Default = standard input.
            -o=FILE, --output=FILE    the text output file.
                                      Default = standard output.
            datFile:                  regex/replacement pairs file. Default = ./regexfilter.dat.
                                      if not found, builds an example file.
---- not used:
            --CTextconfigload=FILE    read option/param from a config file, text mode
                                      (can also contains regex/replacement pairs)
            --CXmlconfigload=FILE     read option/param from a config file, XML mode
                                      (can also contains regex/replacement pairs)
            --CSaveconfig[=FILE]      save all options/parameter to a config file,
                                      default=regexfilter.dat.
 </PRE>
 *<UL>
 * <LI> regex must be double-escaped ('\\') using regex rules (not in XML mode)
 * <LI> in replacement  some chars must be single-escaped ( \", \', \\,
 *     \t, \f, \n, \r [for: ", ', \, TAB, FF, LF, CR chars]) and same for hexadecimal
 *     unicode: \ uxxxx. Some must be double-escaped (\\space, \\$ [for:
 *     initial-final spaces, $ char]).
 * <LI> in replacement $n is a references to 'n' captured subsequences.
 * <LI> extra macros in replacement:<UL>
 * <LI>  \\space is for intial/final spaces
 * <LI>  $V is regexfilter version
 * <LI>  $F is full path of the input file,
 * <LI>  $P is the path (file excluded) of the input file
 * <LI>  $N is the file name (no ext.) of the input file
 * <LI>  $E is the file extension (no dot) of the input file
 * <LI>  $D is the filter (file DAT) name (no ext.)
 * <LI>  $C is the Copyrigth notice
 * <LI>  $T is the timestamp</UL>
 *
 * <LI> replacement allows empty lines (delete).
 * <LI> regex/replacement indexes in 1..999 interval, sequence and order not required.<BR>
 *</UL>
 * <H4> datFile - text format </H4>
 * <PRE># rule 1: replaces "# /**" with "/**"
 regex1=^#[ ]*(/\\*\\*)
 replacement1=$1
 # rule 203: replaces "# *"   with "*"
 regex203=^#[ ]*\\*
 replacement203=*</PRE>
 *
 * <H4> datFile - XML format </H4>
 * <PRE>&lt;comment&gt; rule 1: replaces "# /**" with "/**"  &lt;/comment&gt;
 &lt;entry key="regex1"&gt;^#[ ]*(/\*\*)&lt;/entry&gt;
 &lt;entry key="replacement1"&gt;$1&lt;/entry&gt;
 &lt;comment&gt; rule 2: replaces "# *" with "*"  &lt;/comment&gt;
 &lt;entry key="regex2"&gt;^#[ ]*\*&lt;/entry&gt;
 &lt;entry key="replacement2"&gt;*&lt;/entry&gt;</PRE>
 *

 *
 * @author (c)2006-20015 M. Sillano (marco.sillano@gmail.com)
 * @version 4.03 (15/12/10): Java 1.8, indexes in 1..999, more macros: $E,$D,$C,$T
 * @version 4.02 10/11/25: start version
 */

public class regexfilter extends ms.utils.aarray.baseapp.filter.ZeroFilter {
    // =======================================================
    // standard ZeroFIle extensions
    static private final String version = "regexfilter 4.03 (15/12/10) \n"
            + "Copyright (C) 2006-2015  M.Sillano \n"
            + "License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html> \n"
            + "This is free software: you are free to change and redistribute it. \n"
            + "There is NO WARRANTY, to the extent permitted by law.";

    static private final String[] regexHelp = {
            "Usage:     regexfilter -h|-?|--help|--version",
            "           regexfilter [-bx] [-i=FILE] [-o=FILE] [datFile]",
//          "           regexfilter [--CTextconfigload=FILE]|[--CXmlconfigload=FILE] ",
            "Filters the inputFile, using regex/replacement pairs in datFile.",
            "options:  -h|-?|--help    display this help and exit.",
            "          --version       print version and exit.",
            "          -b              block mode. Default = line mode.",
            "          -x              datFile in XML mode. Default = plain text.",
            "-i=FILE, --input=FILE     the text input file.",
            "                          Default = standard input.",
            "-o=FILE, --output=FILE    the text output file.",
            "                          Default = standard output.",
            "datFile:                  regex/replacement pairs file. Default =regexfilter.dat.",
            "                          if not found, builds an example file."
// not used in regexfilter:
//          "--CTextconfigload=FILE    read option/param from config file, text mode ",
//          "                          (can also contains regex/replacement pairs)",
//          "--CXmlconfigload=FILE     read option/param from config file, XML mode ",
//          "                          (can also contains regex/replacement pairs)",
//          "--CSaveconfig=FILE        save all options/parameter to a config file",
//          "                          default=regexfilter.dat."

    };
    //
    static private final String Opts = "bx";
    //
    static private final String[] Params = { "-input", "i", "-output", "o" };
    //
    static private final String DEFAULT_CONFIG = "regexfilter.cfg";
    static private final String FILETITLE = "by regexfilter 4.02 (10/11/25)";
    // end standard stuff
    // =======================================================

    static private final String DEFAULT_DATAFILE = "regexfilter.dat";

    /**
     * Initializes aaBase and all custom data structures. It uses
     * ZeroFilter.startup for input/output standard processing.
     *
     * @param args
     *            command line from main().
     */
    protected static void startup(String[] args) {
        // =======================================================
        // static setup
        AABaseAppl.version = regexfilter.version;
        AABaseAppl.helpStrings = regexfilter.regexHelp;
        AABaseAppl.fileTitle = regexfilter.FILETITLE;
        // Dynamic setup
        aaBase = new AABaseAppl(Opts, Params);
        aaBase.setConfigFile(DEFAULT_CONFIG);
        ZeroFilter.startup(args);
        // end standard setup
        // =======================================================
        // ...for this filter
        // --- datFile
        if (aaBase.isOption("x"))
            aaBase.setIOMode(AABaseAppl.MODE_XML);
        else
            aaBase.setIOMode(AABaseAppl.MODE_TXT);
        //
        //  from here save config file not allowed ....
        //  merges datafile to cfg file...
        String datFileN = aaBase.getArgument(1);
        if (datFileN != null)
            aaBase.setConfigFile(datFileN);
        else
            aaBase.setConfigFile(DEFAULT_DATAFILE);
        File cnf = new File(aaBase.getConfigFile());
        if (cnf.canRead())
            aaBase.loadConfigFile();
        else
            exampleDatAndDies();
        return;
    }

    /*
     * Creates a example datFile and exit PROCESS_FAILURE;
     */
    private static void exampleDatAndDies() {
        aaBase.cleanAllSpecial(true, true);
        aaBase.setProperty("regex1", "^#[ ]*(/\\*\\*)");
        aaBase.setProperty("replacement1", "$1");
        aaBase.setProperty("regex2", "^#[ ]*\\*");
        aaBase.setProperty("replacement2", "*");
        aaBase.setProperty("regex3", "^#");
        aaBase.setProperty("replacement3", "//");
        aaBase.saveConfigFile();
        aaBase.helpAndDies("ERROR: not found regex definition file: this creates an example file "
                + aaBase.getConfigFile());
    }
// make macro sobstitutions
private static String getReplacement(int i){
    String rep = aaBase.getProperty("replacement" + i);
    String n = null;
    try {
        if (inFile != null){
            if (rep.contains("$F")){  // file input complete path
                n = inFile.getCanonicalPath();
                n = n.replace('\\','#');   // double escaping  / in path
                n = n.replace("#","\\\\");
                rep = rep.replace("$F", n);
            }
            if (rep.contains("$P")){
                n =  inFile.getParentFile().getCanonicalPath();
                n = n.replace('\\','#');   // double escaping  / in path
                n = n.replace("#","\\\\");
                rep = rep.replace("$P", n);
            }
            if (rep.contains("$N"))   // input file name
            {
                n = inFile.getName();
                int x = n.lastIndexOf('.');
                if (x>0)
                    n=n.substring(0, x);
                rep = rep.replace("$N", n);
            }
            if (rep.contains("$E"))   // input file extension
            {
                n = inFile.getName();
                int x = n.lastIndexOf('.');
                rep = rep.replace("$E", x>0 ? n.substring(x+1):"");
            }
        } else {
            rep = rep.replace("$F", "");
            rep = rep.replace("$P", "");
            rep = rep.replace("$N", "");
            rep = rep.replace("$E", "");
        }

        if (rep.contains("$C"))  // Copyrigth notice
        {
           n = "\u00A9 " + Calendar.getInstance().get(Calendar.YEAR) +
                      " " +  System.getProperty("user.name") +", licensed CCAS 3.0, see http://creativecommons.org/ ";
           rep = rep.replace("$C", n);
        }

        if (rep.contains("$D"))   // filter (file DAT) name
        {
           n = aaBase.getConfigFile();
           int x = n.lastIndexOf('.');
           rep = rep.replace("$D", x>0 ? n.substring(0, x): n);
        }

        if (rep.contains("$T"))  // timestamp
        {
           n = "\u00A9 " + Calendar.getInstance().get(Calendar.YEAR) +
                      " " +  System.getProperty("user.name") +", licensed CC BY-SA 3.0, see http://creativecommons.org/ ";
           rep = rep.replace("$T", new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date()) );
        }

        if (rep.contains("$V")){  // version
             String[] vv = version.split("\n");
             rep = rep.replace("$V",  vv[0].trim());
        }


        if (rep.contains("\\space")){  // initial/final spaces
            rep = rep.replace("\\space", " ");
        }
     }
     catch (IOException e) {
            // nothing TODO A
    }
    return rep;
}
    /*
     * processes one String
     * @param xStr the input line or file.
     * @return the input processed
     */
    private static String processed(String xStr) {
       for ( int i = 1; i < 1000; i++){

        try {
          if (aaBase.containsKey("regex" + i)) {
             xStr = xStr.replaceAll(aaBase.getProperty("regex" + i),
                    getReplacement(i));
            }
        }
        catch (Exception e){
            return "ERROR: "+e.toString();
        }
       }
        return xStr;
    }

    /**
     * The main is static. This main uses this.startup() to eval Options and
     * Params, and uses the method process() to make the regex replacements.
     *
     * @param args
     *            command line argoments array processed by startup().
     */
      private static String getDefaultCharSet() {
        OutputStreamWriter writer = new OutputStreamWriter(new ByteArrayOutputStream());
        String enc = writer.getEncoding();
        return enc;
      }

    public static void main(String[] args) {
        startup(args);
        try {
            String iStr = "";
            if (aaBase.isOption("b")) {
                // block mode
                String full = "";
                while (iStr != null) {
                    iStr = fin.readLine();
                    if (iStr != null)
                        full += iStr + newline;
                }
                fout.print(processed(full));
            } else {
                // line mode
                while (iStr != null) {
                    iStr = fin.readLine();
                    if (iStr != null) {
                        fout.println(processed(iStr));
                    }
                }
            }
            fin.close();
            fout.flush();
            fout.close();
        } catch (Exception e) {
            System.err.println("ERROR");
            e.printStackTrace();
            System.exit(AABaseAppl.PROCESS_FAILURE);
        }
    }
}
